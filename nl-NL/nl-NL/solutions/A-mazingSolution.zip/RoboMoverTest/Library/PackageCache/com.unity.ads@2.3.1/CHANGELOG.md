# Changelog

## [2.3.1] - 2018-11-15

### Fixed

 * Update to Ads SDK 2.3.0
 * Multithreaded Request API
 * SendEvent API for Ads and IAP SDK communication
 * New Unity integration

## [2.2.1] - 2017-04-192

### Fixed

 * Fixed issues (iOS, Android)

## [2.2.0] - 2017-03-22

### Added

 * IAP Promotion support (iOS, Android)

### Changed

 * Improved cache handling (iOS, Android)
 * Increased flexibility showing different ad formats (iOS, Android)

### Fixed

 * Fixed a couple of rare crashes (iOS)