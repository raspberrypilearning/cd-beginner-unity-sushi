﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoboMover : MonoBehaviour
{

    public float moveSpeed = 4.0f;
    public Rigidbody rb;
    public Transform tf;

    // Update is called once per frame
    void Update()
    {
      float inputHorizontal = Mathf.Abs (Input.GetAxis ("Horizontal"));
      float inputVertical = Mathf.Abs (Input.GetAxis ("Vertical"));

      if(inputHorizontal > 0.01f || inputVertical > 0.01f){
          Vector3 desiredDirection = new Vector3 (Input.GetAxis ("Horizontal"), 0.0f, Input.GetAxis ("Vertical"));
          desiredDirection = moveSpeed * desiredDirection;
          desiredDirection = Time.deltaTime * desiredDirection;
          rb.MovePosition (rb.position + desiredDirection);
          rb.MoveRotation (Quaternion.LookRotation (desiredDirection, Vector3.up));
          }
    }
}
