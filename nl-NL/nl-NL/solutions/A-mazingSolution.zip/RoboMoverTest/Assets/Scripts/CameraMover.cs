﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMover : MonoBehaviour
{
  public Transform tf;
  public Transform playerTransform;
  public Vector3 distanceBetweenPlayerAndCam;

    // Start is called before the first frame update
    void Start()
    {
        distanceBetweenPlayerAndCam = tf.position - playerTransform.position;
    }

    // Update is called once per frame
    void Update()
    {
        tf.position = playerTransform.position + distanceBetweenPlayerAndCam;
    }
}
