﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinZone : MonoBehaviour
{
  public GameObject fireworks;

  void OnTriggerEnter (Collider col) {
      if (col.transform.CompareTag ("Ball")) {
        fireworks.SetActive (true);
      }
  }
}
